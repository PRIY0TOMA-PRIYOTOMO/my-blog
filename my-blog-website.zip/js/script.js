// Optional JavaScript file
console.log("Blog script loaded.");
